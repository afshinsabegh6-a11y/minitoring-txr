using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.Json;

namespace FileMonitor
{
    public class MainForm : Form
    {
        // --- Controls ---
        private TextBox txtToken;
        private TextBox txtChatId;
        private Button btnSaveSettings;
        private Button btnAddFile;
        private Button btnRemoveFile;
        private Button btnTestTelegram;
        private ListBox lstFiles;
        private ListBox lstLog;
        private Label lblStatus;
        private Panel panelSettings;
        private Panel panelFiles;
        private Panel panelLog;

        // --- State ---
        private readonly List<FileSystemWatcher> _watchers = new List<FileSystemWatcher>();
        private readonly HttpClient _httpClient = new HttpClient();
        private string _settingsFile;

        public MainForm()
        {
            _settingsFile = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                "FileMonitor", "settings.json");

            InitializeUI();
            LoadSettings();
        }

        private void InitializeUI()
        {
            this.Text = "📁 File Monitor - مانیتورینگ فایل";
            this.Size = new Size(750, 700);
            this.MinimumSize = new Size(650, 550);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(245, 247, 250);
            this.Font = new Font("Segoe UI", 9.5f);

            // ===== SETTINGS PANEL =====
            panelSettings = new Panel
            {
                Location = new Point(12, 12),
                Size = new Size(710, 130),
                BackColor = Color.White,
                Padding = new Padding(15)
            };
            panelSettings.Paint += PanelPaint;

            var lblSettingsTitle = new Label
            {
                Text = "⚙️  تنظیمات تلگرام",
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.FromArgb(37, 99, 235),
                Location = new Point(15, 12),
                AutoSize = true
            };

            var lblToken = new Label { Text = "Bot Token:", Location = new Point(15, 45), AutoSize = true, ForeColor = Color.FromArgb(55, 65, 81) };
            txtToken = new TextBox
            {
                Location = new Point(100, 42),
                Size = new Size(390, 25),
                PlaceholderText = "123456789:ABCdefGHIjklMNOpqrsTUVwxyz",
                BorderStyle = BorderStyle.FixedSingle
            };

            var lblChatId = new Label { Text = "Chat ID:", Location = new Point(15, 78), AutoSize = true, ForeColor = Color.FromArgb(55, 65, 81) };
            txtChatId = new TextBox
            {
                Location = new Point(100, 75),
                Size = new Size(180, 25),
                PlaceholderText = "123456789",
                BorderStyle = BorderStyle.FixedSingle
            };

            btnSaveSettings = CreateButton("💾 ذخیره", 295, 72, 100, Color.FromArgb(37, 99, 235));
            btnSaveSettings.Click += BtnSaveSettings_Click;

            btnTestTelegram = CreateButton("🔔 تست", 405, 72, 100, Color.FromArgb(16, 185, 129));
            btnTestTelegram.Click += BtnTestTelegram_Click;

            panelSettings.Controls.AddRange(new Control[] {
                lblSettingsTitle, lblToken, txtToken, lblChatId, txtChatId, btnSaveSettings, btnTestTelegram
            });

            // ===== FILES PANEL =====
            panelFiles = new Panel
            {
                Location = new Point(12, 155),
                Size = new Size(710, 220),
                BackColor = Color.White
            };
            panelFiles.Paint += PanelPaint;

            var lblFilesTitle = new Label
            {
                Text = "📂  فایل‌های زیر نظر",
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.FromArgb(37, 99, 235),
                Location = new Point(15, 12),
                AutoSize = true
            };

            lstFiles = new ListBox
            {
                Location = new Point(15, 45),
                Size = new Size(565, 155),
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Consolas", 9f),
                BackColor = Color.FromArgb(249, 250, 251)
            };

            btnAddFile = CreateButton("➕ افزودن فایل", 595, 45, 105, Color.FromArgb(37, 99, 235));
            btnAddFile.Click += BtnAddFile_Click;

            btnRemoveFile = CreateButton("🗑️ حذف", 595, 85, 105, Color.FromArgb(239, 68, 68));
            btnRemoveFile.Click += BtnRemoveFile_Click;

            panelFiles.Controls.AddRange(new Control[] {
                lblFilesTitle, lstFiles, btnAddFile, btnRemoveFile
            });

            // ===== LOG PANEL =====
            panelLog = new Panel
            {
                Location = new Point(12, 388),
                Size = new Size(710, 250),
                BackColor = Color.White,
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right
            };
            panelLog.Paint += PanelPaint;

            var lblLogTitle = new Label
            {
                Text = "📋  لاگ تغییرات",
                Font = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.FromArgb(37, 99, 235),
                Location = new Point(15, 12),
                AutoSize = true
            };

            var btnClearLog = CreateButton("🧹 پاک کردن", 595, 8, 105, Color.FromArgb(107, 114, 128));
            btnClearLog.Click += (s, e) => lstLog.Items.Clear();

            lstLog = new ListBox
            {
                Location = new Point(15, 45),
                Size = new Size(680, 190),
                BorderStyle = BorderStyle.FixedSingle,
                Font = new Font("Consolas", 8.5f),
                BackColor = Color.FromArgb(15, 23, 42),
                ForeColor = Color.FromArgb(134, 239, 172),
                Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right,
                HorizontalScrollbar = true
            };

            panelLog.Controls.AddRange(new Control[] { lblLogTitle, btnClearLog, lstLog });

            // ===== STATUS BAR =====
            lblStatus = new Label
            {
                Text = "⚪ آماده - هنوز فایلی اضافه نشده",
                Location = new Point(12, 648),
                AutoSize = true,
                ForeColor = Color.FromArgb(107, 114, 128),
                Font = new Font("Segoe UI", 9f)
            };

            this.Controls.AddRange(new Control[] { panelSettings, panelFiles, panelLog, lblStatus });
        }

        private Button CreateButton(string text, int x, int y, int width, Color backColor)
        {
            return new Button
            {
                Text = text,
                Location = new Point(x, y),
                Size = new Size(width, 32),
                BackColor = backColor,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Cursor = Cursors.Hand,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold)
            };
        }

        private void PanelPaint(object sender, PaintEventArgs e)
        {
            var panel = (Panel)sender;
            ControlPaint.DrawBorder(e.Graphics, panel.ClientRectangle,
                Color.FromArgb(229, 231, 235), ButtonBorderStyle.Solid);
        }

        // ===== SETTINGS =====
        private void BtnSaveSettings_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtToken.Text) || string.IsNullOrWhiteSpace(txtChatId.Text))
            {
                ShowMessage("لطفاً توکن و Chat ID را وارد کنید.", MessageBoxIcon.Warning);
                return;
            }
            SaveSettings();
            AddLog("✅ تنظیمات ذخیره شد");
            UpdateStatus("✅ تنظیمات ذخیره شد");
        }

        private async void BtnTestTelegram_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtToken.Text) || string.IsNullOrWhiteSpace(txtChatId.Text))
            {
                ShowMessage("ابتدا توکن و Chat ID را وارد کنید.", MessageBoxIcon.Warning);
                return;
            }
            btnTestTelegram.Enabled = false;
            btnTestTelegram.Text = "...";
            bool ok = await SendTelegramAsync("🟢 سلام! File Monitor آماده به کاره. تغییرات فایل‌ها به اینجا ارسال میشه.");
            btnTestTelegram.Enabled = true;
            btnTestTelegram.Text = "🔔 تست";
            if (ok)
            {
                AddLog("✅ پیام تست با موفقیت ارسال شد");
                ShowMessage("پیام تست ارسال شد! ربات تلگرام رو چک کن ✅", MessageBoxIcon.Information);
            }
            else
            {
                AddLog("❌ خطا در ارسال پیام تست");
                ShowMessage("خطا! توکن یا Chat ID اشتباهه. دوباره چک کن.", MessageBoxIcon.Error);
            }
        }

        // ===== FILE MANAGEMENT =====
        private void BtnAddFile_Click(object sender, EventArgs e)
        {
            using var dlg = new OpenFileDialog
            {
                Title = "انتخاب فایل متنی برای مانیتور",
                Filter = "فایل‌های متنی (*.txt;*.log;*.csv;*.json)|*.txt;*.log;*.csv;*.json|همه فایل‌ها (*.*)|*.*",
                Multiselect = true
            };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            foreach (var path in dlg.FileNames)
            {
                if (lstFiles.Items.Contains(path)) continue;
                lstFiles.Items.Add(path);
                StartWatching(path);
                AddLog($"➕ فایل اضافه شد: {Path.GetFileName(path)}");
            }
            SaveSettings();
            UpdateStatus($"🟢 {lstFiles.Items.Count} فایل زیر نظر");
        }

        private void BtnRemoveFile_Click(object sender, EventArgs e)
        {
            if (lstFiles.SelectedIndex < 0)
            {
                ShowMessage("یه فایل از لیست انتخاب کن.", MessageBoxIcon.Information);
                return;
            }
            var path = lstFiles.SelectedItem.ToString();
            lstFiles.Items.RemoveAt(lstFiles.SelectedIndex);
            StopWatching(path);
            AddLog($"🗑️ فایل حذف شد: {Path.GetFileName(path)}");
            SaveSettings();
            UpdateStatus(lstFiles.Items.Count > 0 ? $"🟢 {lstFiles.Items.Count} فایل زیر نظر" : "⚪ آماده - هنوز فایلی اضافه نشده");
        }

        // ===== WATCHERS =====
        private void StartWatching(string filePath)
        {
            if (!File.Exists(filePath)) return;
            var watcher = new FileSystemWatcher
            {
                Path = Path.GetDirectoryName(filePath),
                Filter = Path.GetFileName(filePath),
                NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.Size,
                EnableRaisingEvents = true
            };
            watcher.Changed += OnFileChanged;
            _watchers.Add(watcher);
        }

        private void StopWatching(string filePath)
        {
            var toRemove = _watchers.FindAll(w =>
                Path.Combine(w.Path, w.Filter).Equals(filePath, StringComparison.OrdinalIgnoreCase));
            foreach (var w in toRemove)
            {
                w.EnableRaisingEvents = false;
                w.Dispose();
                _watchers.Remove(w);
            }
        }

        private DateTime _lastEventTime = DateTime.MinValue;
        private string _lastEventFile = "";

        private async void OnFileChanged(object sender, FileSystemEventArgs e)
        {
            // Debounce: ignore duplicate events within 2 seconds
            if (e.FullPath == _lastEventFile && (DateTime.Now - _lastEventTime).TotalSeconds < 2) return;
            _lastEventFile = e.FullPath;
            _lastEventTime = DateTime.Now;

            var msg = $"📝 فایل تغییر کرد!\n\n🗂 فایل: {e.Name}\n📁 مسیر: {e.FullPath}\n🕐 زمان: {DateTime.Now:yyyy/MM/dd HH:mm:ss}";

            this.Invoke((Action)(() =>
            {
                AddLog($"🔔 تغییر: {e.Name} — {DateTime.Now:HH:mm:ss}");
            }));

            await SendTelegramAsync(msg);
        }

        // ===== TELEGRAM =====
        private async Task<bool> SendTelegramAsync(string text)
        {
            try
            {
                var token = txtToken.Text.Trim();
                var chatId = txtChatId.Text.Trim();
                var url = $"https://api.telegram.org/bot{token}/sendMessage";
                var payload = JsonSerializer.Serialize(new { chat_id = chatId, text });
                var content = new StringContent(payload, Encoding.UTF8, "application/json");
                var resp = await _httpClient.PostAsync(url, content);
                return resp.IsSuccessStatusCode;
            }
            catch { return false; }
        }

        // ===== SETTINGS PERSISTENCE =====
        private void SaveSettings()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(_settingsFile));
                var files = new List<string>();
                foreach (var item in lstFiles.Items) files.Add(item.ToString());
                var data = new { Token = txtToken.Text, ChatId = txtChatId.Text, Files = files };
                File.WriteAllText(_settingsFile, JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch { }
        }

        private void LoadSettings()
        {
            try
            {
                if (!File.Exists(_settingsFile)) return;
                var json = File.ReadAllText(_settingsFile);
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;
                if (root.TryGetProperty("Token", out var t)) txtToken.Text = t.GetString();
                if (root.TryGetProperty("ChatId", out var c)) txtChatId.Text = c.GetString();
                if (root.TryGetProperty("Files", out var files))
                {
                    foreach (var f in files.EnumerateArray())
                    {
                        var path = f.GetString();
                        if (File.Exists(path) && !lstFiles.Items.Contains(path))
                        {
                            lstFiles.Items.Add(path);
                            StartWatching(path);
                        }
                    }
                }
                if (lstFiles.Items.Count > 0)
                    UpdateStatus($"🟢 {lstFiles.Items.Count} فایل زیر نظر");
                AddLog("📂 تنظیمات قبلی بارگذاری شد");
            }
            catch { }
        }

        // ===== HELPERS =====
        private void AddLog(string message)
        {
            if (lstLog.InvokeRequired)
            {
                lstLog.Invoke((Action)(() => AddLog(message)));
                return;
            }
            lstLog.Items.Insert(0, $"[{DateTime.Now:HH:mm:ss}]  {message}");
            if (lstLog.Items.Count > 200) lstLog.Items.RemoveAt(lstLog.Items.Count - 1);
        }

        private void UpdateStatus(string msg)
        {
            if (lblStatus.InvokeRequired)
                lblStatus.Invoke((Action)(() => lblStatus.Text = msg));
            else
                lblStatus.Text = msg;
        }

        private void ShowMessage(string msg, MessageBoxIcon icon) =>
            MessageBox.Show(msg, "File Monitor", MessageBoxButtons.OK, icon);

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            SaveSettings();
            foreach (var w in _watchers) { w.EnableRaisingEvents = false; w.Dispose(); }
            _httpClient.Dispose();
            base.OnFormClosing(e);
        }
    }
}
